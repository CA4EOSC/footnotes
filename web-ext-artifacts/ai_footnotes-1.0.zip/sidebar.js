const chatContainer = document.getElementById('chat-container');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');
const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const saveNoteBtn = document.getElementById('save-note-btn');

let ws = null;
let isWaitingForResponse = false;
let currentThinkingId = null;

let pages = [];
let currentPageIndex = 0;
const messagesContainer = document.getElementById('messages-container');
const paginationContainer = document.getElementById('pagination-container');

// Initialize Markdown parser safely
marked.setOptions({
    breaks: true, // translate newlines into <br>
    gfm: true
});

function updateStatus(connected) {
    if (connected) {
        statusDot.className = "w-2 h-2 rounded-full bg-green-500";
        statusText.textContent = "Connected";
    } else {
        statusDot.className = "w-2 h-2 rounded-full bg-red-500";
        statusText.textContent = "Disconnected";
    }
}

function connect() {
    ws = new WebSocket('ws://127.0.0.1:8775');

    ws.onopen = () => {
        updateStatus(true);
    };

    ws.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);

            if (data.type === 'response') {
                removeThinkingIndicator();
                appendMessage(data.data, 'ai');
                isWaitingForResponse = false;
                updateInputState();
            } else if (data.type === 'error') {
                removeThinkingIndicator();
                appendMessage(`**Error:** ${data.data}`, 'ai', true);
                isWaitingForResponse = false;
                updateInputState();
            } else if (data.type === 'restore_running') {
                // The backend notified us that a task is already running for our dropped connection!
                if (pages.length === 0 || !pages[currentPageIndex].some(m => m.role === 'user')) {
                    appendMessage(data.data, 'user');
                }
                isWaitingForResponse = true;
                updateInputState();
                if (!currentThinkingId) showThinkingIndicator();
            } else if (data.type === 'cache_data') {
                if (data.data && data.data.length > 0) {
                    pages = data.data;
                    currentPageIndex = pages.length - 1;
                    renderPagination();
                    renderCurrentPage();
                } else if (pages.length === 0) {
                    appendMessage('AI Footnotes is online. How can I assist you today?', 'ai');
                }
            }
        } catch (e) {
            console.error("Message parsing failed:", e);
        }
    };

    ws.onclose = () => {
        updateStatus(false);
        // If we were waiting for a response, we stop waiting.
        if (isWaitingForResponse) {
            removeThinkingIndicator();
            appendMessage(`**Connection Lost:** The backend server disconnected before responding. I will retry connecting...`, 'ai', true);
            isWaitingForResponse = false;
            updateInputState();
        }
        setTimeout(connect, 3000);
    };

    ws.onerror = (err) => {
        console.error("WebSocket error:", err);
        // Will close and reconnect natively
    };
}

function updateInputState() {
    if (isWaitingForResponse) {
        sendBtn.disabled = true;
        chatInput.disabled = true;
    } else {
        sendBtn.disabled = false;
        chatInput.disabled = false;
        chatInput.focus();
    }
}

function scrollToBottom() {
    messagesContainer.scrollTo({ top: messagesContainer.scrollHeight, behavior: 'smooth' });
    chatContainer.scrollTo({ top: chatContainer.scrollHeight + 100, behavior: 'smooth' });
}

function createNewPage() {
    pages.push([]);
    currentPageIndex = pages.length - 1;
    renderPagination();
}

function savePagesToBackend() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'save_cache', data: pages }));
    }
}

function appendMessage(text, role, isError = false) {
    if (pages.length === 0) createNewPage();

    // If inserting a user message, and the current page already has an AI response, build a new page!
    if (role === 'user' && pages[currentPageIndex].some(m => m.role === 'ai' && m.text !== 'AI Footnotes is online. How can I assist you today?')) {
        createNewPage();
    }

    pages[currentPageIndex].push({ text, role, isError });
    renderCurrentPage();
    savePagesToBackend();
}

function renderPagination() {
    paginationContainer.innerHTML = '';

    if (pages.length <= 1) return; // Don't show pagination clutter for 1 page

    pages.forEach((page, index) => {
        const btn = document.createElement('button');
        btn.textContent = index + 1;
        btn.className = `w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition cursor-pointer ${index === currentPageIndex ? 'bg-blue-600 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`;

        btn.onclick = () => {
            if (isWaitingForResponse) return; // Prevent switching pages while AI is actively typing
            currentPageIndex = index;
            renderPagination();
            renderCurrentPage();
        };
        paginationContainer.appendChild(btn);
    });
}

function renderCurrentPage() {
    messagesContainer.innerHTML = '';

    if (pages.length === 0) return;

    // Mount all static messages for the requested page
    pages[currentPageIndex].forEach(msg => {
        const wrapper = document.createElement('div');
        wrapper.className = `flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`;

        const bubble = document.createElement('div');
        bubble.className = `bubble p-3 rounded-2xl text-sm shadow-sm ${msg.role === 'user' ? 'bubble-user' : 'bubble-ai'}`;

        if (msg.isError) {
            bubble.classList.add('border-red-300', 'bg-red-50', 'text-red-800');
        }

        if (msg.role === 'ai') {
            bubble.innerHTML = marked.parse(msg.text);
        } else {
            bubble.textContent = msg.text;
        }

        wrapper.appendChild(bubble);
        messagesContainer.appendChild(wrapper);
    });

    // Mount the thinking indicator if this page is actively awaiting context
    if (currentThinkingId && currentPageIndex === pages.length - 1) {
        const wrapper = document.createElement('div');
        wrapper.id = currentThinkingId;
        wrapper.className = `flex w-full justify-start`;

        const bubble = document.createElement('div');
        bubble.className = `bubble p-4 rounded-2xl text-sm shadow-sm bubble-ai flex items-center justify-center`;

        bubble.innerHTML = `<div class="dots"><span></span><span></span><span></span></div>`;

        wrapper.appendChild(bubble);
        messagesContainer.appendChild(wrapper);
    }

    scrollToBottom();
}

function showThinkingIndicator() {
    currentThinkingId = 'think-' + Date.now();
    renderCurrentPage();
}

function removeThinkingIndicator() {
    currentThinkingId = null;
    renderCurrentPage();
}

// Auto-resizing textarea
chatInput.addEventListener('input', function () {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
});

// Handle Enter to send
chatInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        chatForm.dispatchEvent(new Event('submit'));
    }
});

// Handle Submit
chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = chatInput.value.trim();
    if (!text || isWaitingForResponse || !ws || ws.readyState !== WebSocket.OPEN) return;

    appendMessage(text, 'user');
    chatInput.value = '';
    chatInput.style.height = 'auto'; // reset resize

    // Form the websocket packet
    ws.send(JSON.stringify({ type: 'input', data: text }));

    isWaitingForResponse = true;
    updateInputState();
    showThinkingIndicator();
});

// Selection logic for Notetaker skill
document.addEventListener('selectionchange', () => {
    const selection = window.getSelection();
    const text = selection.toString();

    if (text.trim().length > 0) {
        // Calculate position slightly above the selection
        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();

        saveNoteBtn.style.display = 'block';
        saveNoteBtn.style.top = `${rect.top + window.scrollY - 40}px`;

        // Ensure button doesnt render outside view horizontally
        let leftPx = rect.left + (rect.width / 2) - (saveNoteBtn.offsetWidth / 2);
        leftPx = Math.max(10, Math.min(leftPx, window.innerWidth - saveNoteBtn.offsetWidth - 10));
        saveNoteBtn.style.left = `${leftPx}px`;
    } else {
        saveNoteBtn.style.display = 'none';
    }
});

saveNoteBtn.addEventListener('click', () => {
    const text = window.getSelection().toString();
    if (text && ws && ws.readyState === WebSocket.OPEN && !isWaitingForResponse) {
        const command = `Take a note containing this text:\n\n${text}`;

        appendMessage("📌 *Saving captured footnote...*", 'user');
        ws.send(JSON.stringify({ type: 'input', data: command }));

        window.getSelection().removeAllRanges();
        saveNoteBtn.style.display = 'none';

        isWaitingForResponse = true;
        updateInputState();
        showThinkingIndicator();
    }
});

// Initiate connection pipeline
connect();
